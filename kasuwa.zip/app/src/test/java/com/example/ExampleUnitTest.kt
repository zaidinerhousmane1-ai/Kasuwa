package com.example

import com.example.data.model.Debt
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.ui.components.formatFcfa
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testFcfaFormatting() {
        val formatted = formatFcfa(15500)
        assertTrue(formatted.contains("15") && formatted.contains("500") && formatted.endsWith("FCFA"))
    }

    @Test
    fun testProductMarginAndStockStatus() {
        val product = Product(
            id = 1,
            name = "Riz 25kg",
            purchasePrice = 16000,
            sellingPrice = 18500,
            quantity = 3,
            lowStockThreshold = 5
        )
        assertEquals(2500L, product.margin)
        assertTrue(product.isLowStock)
        org.junit.Assert.assertFalse(product.isOutOfStock)
    }

    @Test
    fun testSaleEstimatedProfit() {
        val sale = Sale(
            productId = 1,
            productName = "Riz 25kg",
            quantity = 2,
            unitPrice = 18500,
            totalPrice = 37000,
            unitCostPrice = 16000
        )
        // Profit = (18500 - 16000) * 2 = 5000 FCFA
        assertEquals(5000L, sale.estimatedProfit)
    }

    @Test
    fun testDebtRemainingAmount() {
        val debt = Debt(
            customerName = "Amadou",
            initialAmount = 10000,
            amountPaid = 4000,
            remainingAmount = 6000
        )
        assertEquals(6000L, debt.remainingAmount)
        org.junit.Assert.assertFalse(debt.isPaid)
    }
}
