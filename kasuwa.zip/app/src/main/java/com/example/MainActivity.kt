package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.data.db.KasuwaDatabase
import com.example.data.repository.KasuwaRepository
import com.example.ui.KasuwaMainScreen
import com.example.ui.theme.KasuwaTheme
import com.example.ui.viewmodel.KasuwaViewModel
import com.example.ui.viewmodel.KasuwaViewModelFactory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val repository by lazy {
        val db = KasuwaDatabase.getDatabase(applicationContext)
        KasuwaRepository(db.kasuwaDao())
    }

    private val viewModel: KasuwaViewModel by viewModels {
        KasuwaViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Chargement initial des données de démo si la base est vide
        lifecycleScope.launch {
            val existingProducts = repository.allProducts.first()
            if (existingProducts.isEmpty()) {
                repository.loadDemoData()
            }
        }

        setContent {
            KasuwaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    KasuwaMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
