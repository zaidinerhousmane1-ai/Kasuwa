package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val KasuwaLightColorScheme = lightColorScheme(
    primary = KasuwaGreenPrimary,
    onPrimary = KasuwaGreenOnPrimary,
    primaryContainer = KasuwaGreenContainer,
    onPrimaryContainer = KasuwaGreenOnContainer,
    secondary = KasuwaGoldSecondary,
    onSecondary = KasuwaGoldOnSecondary,
    secondaryContainer = KasuwaGoldContainer,
    onSecondaryContainer = KasuwaGoldOnContainer,
    tertiary = KasuwaBlueTertiary,
    onTertiary = KasuwaBlueOnTertiary,
    tertiaryContainer = KasuwaBlueContainer,
    onTertiaryContainer = KasuwaBlueOnContainer,
    background = KasuwaLightBackground,
    onBackground = KasuwaLightOnSurface,
    surface = KasuwaLightSurface,
    onSurface = KasuwaLightOnSurface,
    surfaceVariant = KasuwaLightSurfaceVariant,
    onSurfaceVariant = KasuwaLightOnSurfaceVariant,
    outline = KasuwaLightOutline,
    outlineVariant = KasuwaLightOutlineVariant,
    error = KasuwaRedDanger,
    onError = Color.White
)

private val KasuwaDarkColorScheme = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF052E16),
    primaryContainer = Color(0xFF166534),
    onPrimaryContainer = Color(0xFFDCFCE7),
    secondary = Color(0xFFFBBF24),
    onSecondary = Color(0xFF451A03),
    secondaryContainer = Color(0xFF78350F),
    onSecondaryContainer = Color(0xFFFEF3C7),
    tertiary = Color(0xFF38BDF8),
    onTertiary = Color(0xFF082F49),
    background = KasuwaDarkBackground,
    onBackground = KasuwaDarkOnSurface,
    surface = KasuwaDarkSurface,
    onSurface = KasuwaDarkOnSurface,
    surfaceVariant = KasuwaDarkSurfaceVariant,
    onSurfaceVariant = KasuwaDarkOnSurfaceVariant,
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A)
)

@Composable
fun KasuwaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) KasuwaDarkColorScheme else KasuwaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
