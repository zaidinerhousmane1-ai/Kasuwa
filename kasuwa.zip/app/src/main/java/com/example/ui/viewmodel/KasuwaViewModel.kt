package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Debt
import com.example.data.model.DebtRepayment
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.data.repository.KasuwaRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardMetrics(
    val todaySalesTotal: Long = 0,
    val todayExpensesTotal: Long = 0,
    val todayCostOfGoods: Long = 0,
    val todayEstimatedProfit: Long = 0,
    val totalPendingDebts: Long = 0,
    val lowStockCount: Int = 0,
    val outOfStockCount: Int = 0,
    val allTimeSalesTotal: Long = 0,
    val allTimeExpensesTotal: Long = 0
)

sealed class KasuwaUiEvent {
    data class ShowMessage(val message: String, val isError: Boolean = false) : KasuwaUiEvent()
}

class KasuwaViewModel(private val repository: KasuwaRepository) : ViewModel() {

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val debts: StateFlow<List<Debt>> = repository.allDebts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val repayments: StateFlow<List<DebtRepayment>> = repository.allRepayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiEvents = MutableSharedFlow<KasuwaUiEvent>()
    val uiEvents: SharedFlow<KasuwaUiEvent> = _uiEvents.asSharedFlow()

    private val _isDemoMode = MutableStateFlow(false)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        products,
        sales,
        expenses,
        debts
    ) { prodList, saleList, expList, debtList ->
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfDay = calendar.timeInMillis

        val activeTodaySales = saleList.filter { !it.isCancelled && it.timestamp >= startOfDay }
        val activeAllSales = saleList.filter { !it.isCancelled }

        val activeTodayExpenses = expList.filter { !it.isCancelled && it.timestamp >= startOfDay }
        val activeAllExpenses = expList.filter { !it.isCancelled }

        val todaySalesTotal = activeTodaySales.sumOf { it.totalPrice }
        val todayExpensesTotal = activeTodayExpenses.sumOf { it.amount }
        val todayCostOfGoods = activeTodaySales.sumOf { it.unitCostPrice * it.quantity }
        val todayProfit = todaySalesTotal - todayCostOfGoods - todayExpensesTotal

        val allSalesTotal = activeAllSales.sumOf { it.totalPrice }
        val allExpensesTotal = activeAllExpenses.sumOf { it.amount }

        val totalPendingDebts = debtList.filter { !it.isPaid }.sumOf { it.remainingAmount }
        val lowStockCount = prodList.count { it.isLowStock }
        val outOfStockCount = prodList.count { it.isOutOfStock }

        DashboardMetrics(
            todaySalesTotal = todaySalesTotal,
            todayExpensesTotal = todayExpensesTotal,
            todayCostOfGoods = todayCostOfGoods,
            todayEstimatedProfit = todayProfit,
            totalPendingDebts = totalPendingDebts,
            lowStockCount = lowStockCount,
            outOfStockCount = outOfStockCount,
            allTimeSalesTotal = allSalesTotal,
            allTimeExpensesTotal = allExpensesTotal
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    init {
        // Au démarrage, si aucune donnée n'existe encore, on charge un jeu de démo pour faciliter la découverte
        viewModelScope.launch {
            // Check if initial load is needed
            // If empty, user can also explicitly click "Charger Démo"
        }
    }

    // === GESTION DES PRODUITS ===
    fun saveProduct(
        id: Long = 0,
        name: String,
        category: String,
        purchasePrice: Long,
        sellingPrice: Long,
        quantity: Int,
        lowStockThreshold: Int,
        unit: String
    ) {
        if (name.isBlank()) {
            emitMessage("Le nom du produit est obligatoire", isError = true)
            return
        }
        if (purchasePrice < 0 || sellingPrice < 0 || quantity < 0) {
            emitMessage("Les montants et quantités doivent être positifs", isError = true)
            return
        }

        viewModelScope.launch {
            val product = Product(
                id = id,
                name = name.trim(),
                category = category.trim().ifBlank { "Alimentation" },
                purchasePrice = purchasePrice,
                sellingPrice = sellingPrice,
                quantity = quantity,
                lowStockThreshold = lowStockThreshold.coerceAtLeast(1),
                unit = unit.trim().ifBlank { "pièce" }
            )
            if (id == 0L) {
                repository.insertProduct(product)
                emitMessage("Produit \"${product.name}\" ajouté avec succès")
            } else {
                repository.updateProduct(product)
                emitMessage("Produit \"${product.name}\" mis à jour")
            }
        }
    }

    fun adjustStock(productId: Long, delta: Int) {
        viewModelScope.launch {
            val product = repository.getProductById(productId) ?: return@launch
            val newQty = product.quantity + delta
            if (newQty < 0) {
                emitMessage("Le stock ne peut pas être négatif !", isError = true)
                return@launch
            }
            repository.updateStock(productId, delta)
            emitMessage("Stock de ${product.name} ajusté ($newQty ${product.unit}s)")
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            emitMessage("Produit \"${product.name}\" supprimé")
        }
    }

    // === GESTION DES VENTES ===
    fun recordSale(
        product: Product?,
        customItemName: String,
        quantity: Int,
        unitPrice: Long,
        unitCostPrice: Long,
        paymentType: String, // CASH, MOBILE_MONEY, CREDIT
        customerName: String,
        customerPhone: String
    ) {
        if (quantity <= 0) {
            emitMessage("La quantité doit être d'au moins 1", isError = true)
            return
        }
        if (unitPrice < 0) {
            emitMessage("Le prix unitaire doit être positif", isError = true)
            return
        }

        // Vérification de stock pour un produit inventorié
        if (product != null) {
            if (product.quantity < quantity) {
                emitMessage(
                    "Stock insuffisant ! Disponible : ${product.quantity} ${product.unit}(s)",
                    isError = true
                )
                return
            }
        }

        val itemName = product?.name ?: customItemName.trim().ifBlank { "Vente diverse" }
        val effectiveCost = product?.purchasePrice ?: unitCostPrice.coerceAtLeast(0L)
        val totalPrice = unitPrice * quantity
        val isCredit = paymentType == "CREDIT"

        if (isCredit && customerName.isBlank()) {
            emitMessage("Le nom du client est requis pour une vente à crédit", isError = true)
            return
        }

        viewModelScope.launch {
            val sale = Sale(
                productId = product?.id,
                productName = itemName,
                quantity = quantity,
                unitPrice = unitPrice,
                totalPrice = totalPrice,
                unitCostPrice = effectiveCost,
                paymentType = paymentType,
                customerName = if (customerName.isNotBlank()) customerName.trim() else null,
                timestamp = System.currentTimeMillis()
            )

            repository.recordSale(
                sale = sale,
                isCreditSale = isCredit,
                customerName = customerName,
                customerPhone = customerPhone
            )

            val msg = if (isCredit) {
                "Vente à crédit de $totalPrice FCFA enregistrée au nom de $customerName"
            } else {
                "Vente de $totalPrice FCFA enregistrée avec succès !"
            }
            emitMessage(msg)
        }
    }

    fun cancelSale(sale: Sale) {
        viewModelScope.launch {
            repository.cancelSale(sale.id)
            emitMessage("Vente de ${sale.productName} annulée. Stock restauré !")
        }
    }

    fun deleteSalePermanent(sale: Sale) {
        viewModelScope.launch {
            // Restore stock if not already cancelled
            if (!sale.isCancelled && sale.productId != null) {
                repository.updateStock(sale.productId, sale.quantity)
            }
            repository.deleteSale(sale)
            emitMessage("Vente supprimée définitivement")
        }
    }

    // === GESTION DES DÉPENSES ===
    fun recordExpense(category: String, amount: Long, description: String) {
        if (amount <= 0) {
            emitMessage("Le montant de la dépense doit être supérieur à 0", isError = true)
            return
        }
        if (description.isBlank()) {
            emitMessage("Veuillez préciser le motif de la dépense", isError = true)
            return
        }

        viewModelScope.launch {
            val expense = Expense(
                category = category.trim().ifBlank { "Divers" },
                amount = amount,
                description = description.trim(),
                timestamp = System.currentTimeMillis()
            )
            repository.insertExpense(expense)
            emitMessage("Dépense de $amount FCFA ($category) enregistrée")
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
            emitMessage("Dépense supprimée")
        }
    }

    // === GESTION DES DETTES CLIENTS ===
    fun recordNewDebt(
        customerName: String,
        customerPhone: String,
        amount: Long,
        notes: String
    ) {
        if (customerName.isBlank()) {
            emitMessage("Le nom du client est obligatoire", isError = true)
            return
        }
        if (amount <= 0) {
            emitMessage("Le montant de la dette doit être supérieur à 0 FCFA", isError = true)
            return
        }

        viewModelScope.launch {
            val debt = Debt(
                customerName = customerName.trim(),
                customerPhone = customerPhone.trim(),
                initialAmount = amount,
                amountPaid = 0,
                remainingAmount = amount,
                status = "PENDING",
                notes = notes.trim(),
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.insertDebt(debt)
            emitMessage("Dette de $amount FCFA enregistrée pour $customerName")
        }
    }

    fun recordDebtRepayment(
        debtId: Long,
        amount: Long,
        paymentMethod: String,
        notes: String
    ) {
        if (amount <= 0) {
            emitMessage("Le montant du remboursement doit être supérieur à 0", isError = true)
            return
        }

        viewModelScope.launch {
            val result = repository.recordDebtRepayment(debtId, amount, paymentMethod, notes)
            if (result > 0) {
                emitMessage("Remboursement de $amount FCFA enregistré avec succès !")
            } else {
                emitMessage("Erreur lors de l'enregistrement du remboursement", isError = true)
            }
        }
    }

    fun deleteDebt(debt: Debt) {
        viewModelScope.launch {
            repository.deleteDebt(debt)
            emitMessage("Fiche de dette supprimée")
        }
    }

    // === GESTION DES DONNÉES DE DÉMO & RESET ===
    fun loadDemoDataset() {
        viewModelScope.launch {
            repository.loadDemoData()
            _isDemoMode.value = true
            emitMessage("Données de démonstration chargées (Niamey / Niger)")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            _isDemoMode.value = false
            emitMessage("Toutes les données ont été réinitialisées")
        }
    }

    private fun emitMessage(msg: String, isError: Boolean = false) {
        viewModelScope.launch {
            _uiEvents.emit(KasuwaUiEvent.ShowMessage(msg, isError))
        }
    }
}

class KasuwaViewModelFactory(private val repository: KasuwaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(KasuwaViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return KasuwaViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
