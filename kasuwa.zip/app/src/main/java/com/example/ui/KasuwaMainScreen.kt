package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.AddDebtDialog
import com.example.ui.screens.AddExpenseDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DebtsScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.ProductFormDialog
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.SalesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.viewmodel.KasuwaUiEvent
import com.example.ui.viewmodel.KasuwaViewModel

enum class KasuwaNavTab(val title: String) {
    DASHBOARD("Accueil"),
    SALES("Ventes"),
    PRODUCTS("Stock"),
    DEBTS("Dettes"),
    HISTORY("Journal"),
    EXPENSES("Dépenses"),
    SETTINGS("Paramètres")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KasuwaMainScreen(
    viewModel: KasuwaViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(KasuwaNavTab.DASHBOARD) }

    val products by viewModel.products.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val expenses by viewModel.expenses.collectAsStateWithLifecycle()
    val debts by viewModel.debts.collectAsStateWithLifecycle()
    val repayments by viewModel.repayments.collectAsStateWithLifecycle()
    val metrics by viewModel.dashboardMetrics.collectAsStateWithLifecycle()
    val isDemoMode by viewModel.isDemoMode.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Quick Dialog states
    var showQuickExpenseDialog by remember { mutableStateOf(false) }
    var showQuickProductDialog by remember { mutableStateOf(false) }
    var showQuickDebtDialog by remember { mutableStateOf(false) }

    // Interception des événements UI pour le Snackbar
    LaunchedEffect(Unit) {
        viewModel.uiEvents.collect { event ->
            when (event) {
                is KasuwaUiEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(
                        message = event.message,
                        withDismissAction = true
                    )
                }
            }
        }
    }

    // Gestion du retour système
    BackHandler(enabled = currentTab != KasuwaNavTab.DASHBOARD) {
        currentTab = KasuwaNavTab.DASHBOARD
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentTab) {
                            KasuwaNavTab.DASHBOARD -> "Kasuwa"
                            KasuwaNavTab.SALES -> "Caisse & Ventes"
                            KasuwaNavTab.PRODUCTS -> "Gestion du Stock"
                            KasuwaNavTab.DEBTS -> "Carnet de Dettes"
                            KasuwaNavTab.HISTORY -> "Journal des Opérations"
                            KasuwaNavTab.EXPENSES -> "Dépenses"
                            KasuwaNavTab.SETTINGS -> "Paramètres & Données"
                        },
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                },
                actions = {
                    IconButton(
                        onClick = { currentTab = KasuwaNavTab.SETTINGS },
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Paramètres",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                NavigationBarItem(
                    selected = currentTab == KasuwaNavTab.DASHBOARD,
                    onClick = { currentTab = KasuwaNavTab.DASHBOARD },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Accueil") },
                    label = { Text("Accueil") },
                    modifier = Modifier.testTag("nav_tab_dashboard")
                )
                NavigationBarItem(
                    selected = currentTab == KasuwaNavTab.SALES,
                    onClick = { currentTab = KasuwaNavTab.SALES },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = "Ventes") },
                    label = { Text("Vente") },
                    modifier = Modifier.testTag("nav_tab_sales")
                )
                NavigationBarItem(
                    selected = currentTab == KasuwaNavTab.PRODUCTS,
                    onClick = { currentTab = KasuwaNavTab.PRODUCTS },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Stock") },
                    label = { Text("Stock") },
                    modifier = Modifier.testTag("nav_tab_products")
                )
                NavigationBarItem(
                    selected = currentTab == KasuwaNavTab.DEBTS,
                    onClick = { currentTab = KasuwaNavTab.DEBTS },
                    icon = { Icon(Icons.Default.CreditCard, contentDescription = "Dettes") },
                    label = { Text("Dettes") },
                    modifier = Modifier.testTag("nav_tab_debts")
                )
                NavigationBarItem(
                    selected = currentTab == KasuwaNavTab.HISTORY || currentTab == KasuwaNavTab.EXPENSES,
                    onClick = { currentTab = KasuwaNavTab.HISTORY },
                    icon = { Icon(Icons.Default.History, contentDescription = "Journal") },
                    label = { Text("Journal") },
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                KasuwaNavTab.DASHBOARD -> DashboardScreen(
                    metrics = metrics,
                    products = products,
                    recentSales = sales,
                    isDemoMode = isDemoMode,
                    onNavigateToSales = { currentTab = KasuwaNavTab.SALES },
                    onNavigateToProducts = { currentTab = KasuwaNavTab.PRODUCTS },
                    onNavigateToDebts = { currentTab = KasuwaNavTab.DEBTS },
                    onNavigateToHistory = { currentTab = KasuwaNavTab.HISTORY },
                    onOpenQuickSaleDialog = { currentTab = KasuwaNavTab.SALES },
                    onOpenQuickExpenseDialog = { showQuickExpenseDialog = true },
                    onOpenAddProductDialog = { showQuickProductDialog = true },
                    onOpenAddDebtDialog = { showQuickDebtDialog = true },
                    onLoadDemoData = { viewModel.loadDemoDataset() }
                )

                KasuwaNavTab.SALES -> SalesScreen(
                    products = products,
                    recentSales = sales,
                    onRecordSale = { prod, customName, qty, uPrice, costPrice, pType, cName, cPhone ->
                        viewModel.recordSale(prod, customName, qty, uPrice, costPrice, pType, cName, cPhone)
                    }
                )

                KasuwaNavTab.PRODUCTS -> ProductsScreen(
                    products = products,
                    onSaveProduct = { id, name, cat, pPrice, sPrice, qty, th, unit ->
                        viewModel.saveProduct(id, name, cat, pPrice, sPrice, qty, th, unit)
                    },
                    onAdjustStock = { prodId, delta ->
                        viewModel.adjustStock(prodId, delta)
                    },
                    onDeleteProduct = { prod ->
                        viewModel.deleteProduct(prod)
                    }
                )

                KasuwaNavTab.DEBTS -> DebtsScreen(
                    debts = debts,
                    onAddDebt = { name, phone, amount, notes ->
                        viewModel.recordNewDebt(name, phone, amount, notes)
                    },
                    onRecordRepayment = { debtId, amount, method, notes ->
                        viewModel.recordDebtRepayment(debtId, amount, method, notes)
                    },
                    onDeleteDebt = { debt ->
                        viewModel.deleteDebt(debt)
                    }
                )

                KasuwaNavTab.HISTORY -> HistoryScreen(
                    sales = sales,
                    expenses = expenses,
                    repayments = repayments,
                    onCancelSale = { sale -> viewModel.cancelSale(sale) },
                    onDeleteSale = { sale -> viewModel.deleteSalePermanent(sale) },
                    onDeleteExpense = { exp -> viewModel.deleteExpense(exp) }
                )

                KasuwaNavTab.EXPENSES -> ExpensesScreen(
                    expenses = expenses,
                    onAddExpense = { cat, amt, desc ->
                        viewModel.recordExpense(cat, amt, desc)
                    },
                    onDeleteExpense = { exp ->
                        viewModel.deleteExpense(exp)
                    }
                )

                KasuwaNavTab.SETTINGS -> SettingsScreen(
                    isDemoMode = isDemoMode,
                    onLoadDemoData = { viewModel.loadDemoDataset() },
                    onClearAllData = { viewModel.clearAllData() }
                )
            }
        }
    }

    // Dialogue d'enregistrement rapide de dépense
    if (showQuickExpenseDialog) {
        AddExpenseDialog(
            onDismiss = { showQuickExpenseDialog = false },
            onConfirm = { cat, amt, desc ->
                viewModel.recordExpense(cat, amt, desc)
                showQuickExpenseDialog = false
            }
        )
    }

    // Dialogue d'ajout rapide de produit
    if (showQuickProductDialog) {
        ProductFormDialog(
            initialProduct = null,
            onDismiss = { showQuickProductDialog = false },
            onSave = { id, name, cat, pPrice, sPrice, qty, th, unit ->
                viewModel.saveProduct(id, name, cat, pPrice, sPrice, qty, th, unit)
                showQuickProductDialog = false
            }
        )
    }

    // Dialogue d'ajout rapide de dette
    if (showQuickDebtDialog) {
        AddDebtDialog(
            onDismiss = { showQuickDebtDialog = false },
            onConfirm = { name, phone, amount, notes ->
                viewModel.recordNewDebt(name, phone, amount, notes)
                showQuickDebtDialog = false
            }
        )
    }
}
