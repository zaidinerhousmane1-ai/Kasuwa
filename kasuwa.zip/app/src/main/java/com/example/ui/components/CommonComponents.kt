package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.KasuwaGreenSuccess
import com.example.ui.theme.KasuwaOrangeWarning
import com.example.ui.theme.KasuwaRedDanger
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Formate un montant en Francs CFA avec des espaces pour les milliers (ex: 15 500 FCFA).
 */
fun formatFcfa(amount: Long): String {
    val formatter = NumberFormat.getIntegerInstance(Locale.FRENCH)
    return "${formatter.format(amount)} FCFA"
}

fun formatDateTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRENCH)
    return sdf.format(Date(timestamp))
}

fun formatDateShort(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.FRENCH)
    return sdf.format(Date(timestamp))
}

@Composable
fun StockBadge(
    quantity: Int,
    threshold: Int = 5,
    unit: String = "pièce",
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when {
        quantity <= 0 -> Triple(
            KasuwaRedDanger.copy(alpha = 0.15f),
            KasuwaRedDanger,
            "Rupture de stock (0)"
        )
        quantity <= threshold -> Triple(
            KasuwaOrangeWarning.copy(alpha = 0.18f),
            KasuwaOrangeWarning,
            "Stock faible : $quantity $unit"
        )
        else -> Triple(
            KasuwaGreenSuccess.copy(alpha = 0.15f),
            KasuwaGreenSuccess,
            "En stock : $quantity $unit"
        )
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = textColor,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun AccountingDisclaimerCard(
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("accounting_disclaimer_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Information comptable",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Avertissement de gestion & transparence",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Le chiffre d'affaires ne représente pas le bénéfice net. Les gains indiqués sont des estimations indicatives calculées à partir des prix d'achat déclarés et des dépenses saisies. Ce calcul ne remplace pas une comptabilité certifiée.",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    lineHeight = 15.sp
                )
            }
        }
    }
}
