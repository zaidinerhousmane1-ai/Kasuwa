package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Palette Kasuwa - Tons Marché Ouest-Africain & Sahel
val KasuwaGreenPrimary = Color(0xFF0D5C3A)
val KasuwaGreenOnPrimary = Color(0xFFFFFFFF)
val KasuwaGreenContainer = Color(0xFFE2F6EA)
val KasuwaGreenOnContainer = Color(0xFF053D25)

val KasuwaGoldSecondary = Color(0xFFB45309)
val KasuwaGoldOnSecondary = Color(0xFFFFFFFF)
val KasuwaGoldContainer = Color(0xFFFEF3C7)
val KasuwaGoldOnContainer = Color(0xFF78350F)

val KasuwaBlueTertiary = Color(0xFF0369A1)
val KasuwaBlueOnTertiary = Color(0xFFFFFFFF)
val KasuwaBlueContainer = Color(0xFFE0F2FE)
val KasuwaBlueOnContainer = Color(0xFF0C4A6E)

val KasuwaLightBackground = Color(0xFFF7FAF8)
val KasuwaLightSurface = Color(0xFFFFFFFF)
val KasuwaLightSurfaceVariant = Color(0xFFEEF3EF)
val KasuwaLightOutline = Color(0xFFCBD5E1)
val KasuwaLightOutlineVariant = Color(0xFFE2E8F0)
val KasuwaLightOnSurface = Color(0xFF0F172A)
val KasuwaLightOnSurfaceVariant = Color(0xFF475569)

val KasuwaDarkBackground = Color(0xFF0F1713)
val KasuwaDarkSurface = Color(0xFF16221D)
val KasuwaDarkSurfaceVariant = Color(0xFF1E2E27)
val KasuwaDarkOnSurface = Color(0xFFF1F5F9)
val KasuwaDarkOnSurfaceVariant = Color(0xFF94A3B8)

val KasuwaRedDanger = Color(0xFFDC2626)
val KasuwaOrangeWarning = Color(0xFFEA580C)
val KasuwaGreenSuccess = Color(0xFF16A34A)
