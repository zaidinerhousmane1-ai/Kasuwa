package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.StockBadge
import com.example.ui.components.formatFcfa
import com.example.ui.theme.KasuwaGreenSuccess
import com.example.ui.theme.KasuwaOrangeWarning
import com.example.ui.theme.KasuwaRedDanger

@Composable
fun ProductsScreen(
    products: List<Product>,
    onSaveProduct: (id: Long, name: String, category: String, purchasePrice: Long, sellingPrice: Long, quantity: Int, lowStockThreshold: Int, unit: String) -> Unit,
    onAdjustStock: (productId: Long, delta: Int) -> Unit,
    onDeleteProduct: (product: Product) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tous") }
    var selectedStockFilter by remember { mutableStateOf("Tous") }

    var showEditDialog by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    val categories = remember(products) {
        listOf("Tous") + products.map { it.category }.distinct().filter { it.isNotBlank() }
    }

    val filteredProducts = products.filter { p ->
        val matchesSearch = p.name.contains(searchQuery, ignoreCase = true) ||
                p.category.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == "Tous" || p.category == selectedCategory
        val matchesStock = when (selectedStockFilter) {
            "Stock faible" -> p.isLowStock
            "En rupture" -> p.isOutOfStock
            else -> true
        }
        matchesSearch && matchesCategory && matchesStock
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    productToEdit = null
                    showEditDialog = true
                },
                modifier = Modifier.testTag("add_product_fab"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter un produit")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .testTag("products_screen")
        ) {
            // Barre de recherche
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("product_search_input"),
                placeholder = { Text("Rechercher un produit...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Filtres par Catégorie
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) }
                    )
                }
            }

            // Filtres par État du Stock
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf("Tous", "Stock faible", "En rupture")) { filter ->
                    FilterChip(
                        selected = selectedStockFilter == filter,
                        onClick = { selectedStockFilter = filter },
                        label = { Text(filter) }
                    )
                }
            }

            // Liste des produits
            if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inventory,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "Aucun produit ne correspond à la recherche" else "Aucun produit dans le catalogue",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { product ->
                        ProductItemCard(
                            product = product,
                            onEdit = {
                                productToEdit = product
                                showEditDialog = true
                            },
                            onDelete = { productToDelete = product },
                            onAdjustStock = onAdjustStock
                        )
                    }
                }
            }
        }
    }

    // Boîte de dialogue Ajouter / Modifier Produit
    if (showEditDialog) {
        ProductFormDialog(
            initialProduct = productToEdit,
            onDismiss = { showEditDialog = false },
            onSave = { id, name, category, purchasePrice, sellingPrice, qty, threshold, unit ->
                onSaveProduct(id, name, category, purchasePrice, sellingPrice, qty, threshold, unit)
                showEditDialog = false
            }
        )
    }

    // Confirmation de suppression
    if (productToDelete != null) {
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = { Text("Supprimer le produit ?") },
            text = { Text("Voulez-vous vraiment supprimer \"${productToDelete?.name}\" du stock ?") },
            confirmButton = {
                Button(
                    onClick = {
                        productToDelete?.let { onDeleteProduct(it) }
                        productToDelete = null
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = KasuwaRedDanger
                    )
                ) {
                    Text("Supprimer")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAdjustStock: (Long, Int) -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Ligne 1 : Nom et Badge de stock
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = product.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StockBadge(
                    quantity = product.quantity,
                    threshold = product.lowStockThreshold,
                    unit = product.unit
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Ligne 2 : Prix de vente, Prix d'achat, Marge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Prix de vente",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatFcfa(product.sellingPrice),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Column {
                    Text(
                        text = "Prix d'achat",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatFcfa(product.purchasePrice),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Marge / unité",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val marginColor = if (product.margin >= 0) KasuwaGreenSuccess else KasuwaRedDanger
                    Text(
                        text = formatFcfa(product.margin),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = marginColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ligne 3 : Boutons d'ajustement rapide de stock & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Ajustement du stock au doigt (boutons >= 48dp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Stock :",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium
                    )

                    OutlinedButton(
                        onClick = { onAdjustStock(product.id, -1) },
                        enabled = product.quantity > 0,
                        modifier = Modifier.size(height = 36.dp, width = 48.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("-1", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { onAdjustStock(product.id, 1) },
                        modifier = Modifier.size(height = 36.dp, width = 48.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+1", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { onAdjustStock(product.id, 5) },
                        modifier = Modifier.size(height = 36.dp, width = 50.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+5", fontWeight = FontWeight.Bold)
                    }
                }

                // Boutons d'édition & suppression
                Row {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Modifier",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Supprimer",
                            tint = KasuwaRedDanger,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProductFormDialog(
    initialProduct: Product?,
    onDismiss: () -> Unit,
    onSave: (id: Long, name: String, category: String, purchasePrice: Long, sellingPrice: Long, quantity: Int, threshold: Int, unit: String) -> Unit
) {
    var name by remember { mutableStateOf(initialProduct?.name ?: "") }
    var category by remember { mutableStateOf(initialProduct?.category ?: "Alimentation") }
    var purchasePriceStr by remember { mutableStateOf(initialProduct?.purchasePrice?.toString() ?: "") }
    var sellingPriceStr by remember { mutableStateOf(initialProduct?.sellingPrice?.toString() ?: "") }
    var quantityStr by remember { mutableStateOf(initialProduct?.quantity?.toString() ?: "10") }
    var thresholdStr by remember { mutableStateOf(initialProduct?.lowStockThreshold?.toString() ?: "5") }
    var unit by remember { mutableStateOf(initialProduct?.unit ?: "pièce") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialProduct == null) "Nouveau produit" else "Modifier le produit")
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            errorMessage = null
                        },
                        label = { Text("Nom du produit *") },
                        placeholder = { Text("ex: Sac de riz 25kg") },
                        modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Catégorie") },
                        placeholder = { Text("Alimentation, Boissons, Hygiène...") },
                        modifier = Modifier.fillMaxWidth().testTag("product_category_input"),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = purchasePriceStr,
                            onValueChange = {
                                purchasePriceStr = it.filter { ch -> ch.isDigit() }
                                errorMessage = null
                            },
                            label = { Text("Prix d'achat (FCFA) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("product_purchase_price_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = sellingPriceStr,
                            onValueChange = {
                                sellingPriceStr = it.filter { ch -> ch.isDigit() }
                                errorMessage = null
                            },
                            label = { Text("Prix de vente (FCFA) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("product_selling_price_input"),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = {
                                quantityStr = it.filter { ch -> ch.isDigit() }
                                errorMessage = null
                            },
                            label = { Text("Stock initial *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("product_quantity_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("Unité") },
                            placeholder = { Text("sac, carton, kg...") },
                            modifier = Modifier.weight(1f).testTag("product_unit_input"),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = thresholdStr,
                        onValueChange = { thresholdStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Seuil alerte stock bas") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("product_threshold_input"),
                        singleLine = true
                    )
                }

                if (errorMessage != null) {
                    item {
                        Text(
                            text = errorMessage ?: "",
                            color = KasuwaRedDanger,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "Le nom du produit est requis."
                        return@Button
                    }
                    val pPrice = purchasePriceStr.toLongOrNull() ?: 0L
                    val sPrice = sellingPriceStr.toLongOrNull() ?: 0L
                    val qty = quantityStr.toIntOrNull() ?: 0
                    val th = thresholdStr.toIntOrNull() ?: 5

                    if (sPrice < pPrice) {
                        // Attention vente à perte
                    }

                    onSave(
                        initialProduct?.id ?: 0L,
                        name,
                        category,
                        pPrice,
                        sPrice,
                        qty,
                        th,
                        unit
                    )
                },
                modifier = Modifier.testTag("save_product_button")
            ) {
                Text("Enregistrer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Annuler")
            }
        }
    )
}
