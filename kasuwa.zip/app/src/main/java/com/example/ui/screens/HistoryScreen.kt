package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DebtRepayment
import com.example.data.model.Expense
import com.example.data.model.Sale
import com.example.ui.components.formatDateTime
import com.example.ui.components.formatFcfa
import com.example.ui.theme.KasuwaGreenSuccess
import com.example.ui.theme.KasuwaOrangeWarning
import com.example.ui.theme.KasuwaRedDanger

sealed class OperationItem(val timestamp: Long) {
    data class SaleOp(val sale: Sale) : OperationItem(sale.timestamp)
    data class ExpenseOp(val expense: Expense) : OperationItem(expense.timestamp)
    data class RepaymentOp(val repayment: DebtRepayment) : OperationItem(repayment.timestamp)
}

@Composable
fun HistoryScreen(
    sales: List<Sale>,
    expenses: List<Expense>,
    repayments: List<DebtRepayment>,
    onCancelSale: (Sale) -> Unit,
    onDeleteSale: (Sale) -> Unit,
    onDeleteExpense: (Expense) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTypeFilter by remember { mutableStateOf("Toutes") }
    var saleToCancel by remember { mutableStateOf<Sale?>(null) }
    var saleToDelete by remember { mutableStateOf<Sale?>(null) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }

    val allOperations = remember(sales, expenses, repayments) {
        val list = mutableListOf<OperationItem>()
        sales.forEach { list.add(OperationItem.SaleOp(it)) }
        expenses.forEach { list.add(OperationItem.ExpenseOp(it)) }
        repayments.forEach { list.add(OperationItem.RepaymentOp(it)) }
        list.sortedByDescending { it.timestamp }
    }

    val filteredOperations = allOperations.filter { op ->
        when (selectedTypeFilter) {
            "Ventes" -> op is OperationItem.SaleOp
            "Dépenses" -> op is OperationItem.ExpenseOp
            "Remboursements" -> op is OperationItem.RepaymentOp
            else -> true
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("history_screen")
    ) {
        // En-tête
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Journal des opérations",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Historique complet des ventes, dépenses et remboursements",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Filtres rapides
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Toutes", "Ventes", "Dépenses", "Remboursements").forEach { filter ->
                    FilterChip(
                        selected = selectedTypeFilter == filter,
                        onClick = { selectedTypeFilter = filter },
                        label = { Text(filter) }
                    )
                }
            }
        }

        // Liste
        if (filteredOperations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Aucune opération enregistrée",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredOperations, key = {
                    when (it) {
                        is OperationItem.SaleOp -> "sale_${it.sale.id}"
                        is OperationItem.ExpenseOp -> "exp_${it.expense.id}"
                        is OperationItem.RepaymentOp -> "rep_${it.repayment.id}"
                    }
                }) { op ->
                    when (op) {
                        is OperationItem.SaleOp -> SaleOperationCard(
                            sale = op.sale,
                            onCancelClick = { saleToCancel = op.sale },
                            onDeleteClick = { saleToDelete = op.sale }
                        )
                        is OperationItem.ExpenseOp -> ExpenseOperationCard(
                            expense = op.expense,
                            onDeleteClick = { expenseToDelete = op.expense }
                        )
                        is OperationItem.RepaymentOp -> RepaymentOperationCard(
                            repayment = op.repayment
                        )
                    }
                }
            }
        }
    }

    // Dialogue Annulation Vente (Restitue le stock)
    if (saleToCancel != null) {
        AlertDialog(
            onDismissRequest = { saleToCancel = null },
            title = { Text("Annuler cette vente ?") },
            text = {
                Text(
                    "L'annulation va restituer les ${saleToCancel?.quantity} article(s) au stock disponible et marquer l'opération comme annulée."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        saleToCancel?.let { onCancelSale(it) }
                        saleToCancel = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KasuwaOrangeWarning)
                ) {
                    Text("Confirmer l'annulation")
                }
            },
            dismissButton = {
                TextButton(onClick = { saleToCancel = null }) {
                    Text("Retour")
                }
            }
        )
    }

    // Dialogue Suppression Vente définitive
    if (saleToDelete != null) {
        AlertDialog(
            onDismissRequest = { saleToDelete = null },
            title = { Text("Supprimer définitivement la vente ?") },
            text = { Text("Cette action retirera définitivement cette vente du journal.") },
            confirmButton = {
                Button(
                    onClick = {
                        saleToDelete?.let { onDeleteSale(it) }
                        saleToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KasuwaRedDanger)
                ) {
                    Text("Supprimer")
                }
            },
            dismissButton = {
                TextButton(onClick = { saleToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }

    // Dialogue Suppression Dépense
    if (expenseToDelete != null) {
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = { Text("Supprimer cette dépense ?") },
            text = { Text("Voulez-vous supprimer cette dépense de ${formatFcfa(expenseToDelete?.amount ?: 0)} ?") },
            confirmButton = {
                Button(
                    onClick = {
                        expenseToDelete?.let { onDeleteExpense(it) }
                        expenseToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KasuwaRedDanger)
                ) {
                    Text("Supprimer")
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToDelete = null }) {
                    Text("Annuler")
                }
            }
        )
    }
}

@Composable
fun SaleOperationCard(
    sale: Sale,
    onCancelClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (sale.isCancelled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (sale.isCancelled) Color.Gray.copy(alpha = 0.2f) else KasuwaGreenSuccess.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = null,
                            tint = if (sale.isCancelled) Color.Gray else KasuwaGreenSuccess,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = sale.productName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            textDecoration = if (sale.isCancelled) TextDecoration.LineThrough else TextDecoration.None
                        )
                        val extra = if (sale.customerName != null) " • Client : ${sale.customerName}" else ""
                        Text(
                            text = "Vente (${sale.quantity}x)$extra • ${formatDateTime(sale.timestamp)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "+${formatFcfa(sale.totalPrice)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (sale.isCancelled) Color.Gray else KasuwaGreenSuccess,
                        textDecoration = if (sale.isCancelled) TextDecoration.LineThrough else TextDecoration.None
                    )
                    Text(
                        text = if (sale.isCancelled) "Annulée" else sale.paymentType,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (sale.isCancelled) KasuwaRedDanger else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (sale.isCancelled) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }

            // Options de gestion (Annuler / Supprimer)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!sale.isCancelled) {
                    TextButton(onClick = onCancelClick) {
                        Icon(
                            imageVector = Icons.Default.Cancel,
                            contentDescription = null,
                            tint = KasuwaOrangeWarning,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Annuler (Restituer stock)", color = KasuwaOrangeWarning, fontSize = 12.sp)
                    }
                }
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Supprimer définitivement",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ExpenseOperationCard(
    expense: Expense,
    onDeleteClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(KasuwaOrangeWarning.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MoneyOff,
                        contentDescription = null,
                        tint = KasuwaOrangeWarning,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = expense.description,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Dépense (${expense.category}) • ${formatDateTime(expense.timestamp)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "-${formatFcfa(expense.amount)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = KasuwaOrangeWarning
                )
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Supprimer",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RepaymentOperationCard(
    repayment: DebtRepayment
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Payments,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Remboursement de dette",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Client : ${repayment.customerName} • ${formatDateTime(repayment.timestamp)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = "+${formatFcfa(repayment.amount)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.tertiary
            )
        }
    }
}
