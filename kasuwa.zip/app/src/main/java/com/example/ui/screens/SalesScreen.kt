package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.ui.components.StockBadge
import com.example.ui.components.formatDateShort
import com.example.ui.components.formatFcfa
import com.example.ui.theme.KasuwaGreenSuccess
import com.example.ui.theme.KasuwaOrangeWarning
import com.example.ui.theme.KasuwaRedDanger

@Composable
fun SalesScreen(
    products: List<Product>,
    recentSales: List<Sale>,
    onRecordSale: (product: Product?, customItemName: String, qty: Int, unitPrice: Long, costPrice: Long, paymentType: String, customerName: String, customerPhone: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isDirectSaleMode by remember { mutableStateOf(false) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var customName by remember { mutableStateOf("") }
    var quantity by remember { mutableIntStateOf(1) }
    var unitPrice by remember { mutableLongStateOf(0L) }
    var unitCostPrice by remember { mutableLongStateOf(0L) }

    var paymentType by remember { mutableStateOf("CASH") } // CASH, MOBILE_MONEY, CREDIT
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }

    val totalPrice = unitPrice * quantity
    val isStockInsufficient = selectedProduct != null && selectedProduct!!.quantity < quantity

    val availableProducts = products.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("sales_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Enregistrer une vente",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Sélectionnez un article du stock ou saisissez une vente libre",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Mode : Article du Stock vs Vente Libre
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !isDirectSaleMode,
                    onClick = {
                        isDirectSaleMode = false
                        if (selectedProduct != null) {
                            unitPrice = selectedProduct!!.sellingPrice
                            unitCostPrice = selectedProduct!!.purchasePrice
                        }
                    },
                    label = { Text("Article en stock") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = isDirectSaleMode,
                    onClick = {
                        isDirectSaleMode = true
                        selectedProduct = null
                        unitPrice = 0L
                        unitCostPrice = 0L
                    },
                    label = { Text("Vente libre directe") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section sélection de produit ou saisie libre
        if (!isDirectSaleMode) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sales_product_search"),
                        placeholder = { Text("Rechercher un produit...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (selectedProduct != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    2.dp,
                                    MaterialTheme.colorScheme.primary,
                                    RoundedCornerShape(12.dp)
                                ),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = selectedProduct!!.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Prix : ${formatFcfa(selectedProduct!!.sellingPrice)} • Stock actuel : ${selectedProduct!!.quantity} ${selectedProduct!!.unit}(s)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(
                                    onClick = {
                                        selectedProduct = null
                                        unitPrice = 0L
                                    }
                                ) {
                                    Text("Changer")
                                }
                            }
                        }
                    } else {
                        // Liste de sélection de produit
                        Text(
                            text = "Touchez un produit pour le sélectionner :",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (availableProducts.isEmpty()) {
                            Text(
                                text = "Aucun produit trouvé. Créez des articles dans l'onglet Stock.",
                                style = MaterialTheme.typography.bodySmall,
                                color = KasuwaOrangeWarning
                            )
                        } else {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                items(availableProducts) { prod ->
                                    val isSelected = selectedProduct?.id == prod.id
                                    Card(
                                        modifier = Modifier
                                            .width(160.dp)
                                            .clickable {
                                                selectedProduct = prod
                                                unitPrice = prod.sellingPrice
                                                unitCostPrice = prod.purchasePrice
                                                quantity = 1
                                            },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = prod.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = formatFcfa(prod.sellingPrice),
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            StockBadge(
                                                quantity = prod.quantity,
                                                threshold = prod.lowStockThreshold,
                                                unit = prod.unit
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Vente Libre
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        label = { Text("Désignation de l'article") },
                        placeholder = { Text("ex: Bananes, Pain, Carte recharge...") },
                        modifier = Modifier.fillMaxWidth().testTag("custom_sale_name_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = if (unitPrice == 0L) "" else unitPrice.toString(),
                        onValueChange = {
                            unitPrice = it.filter { ch -> ch.isDigit() }.toLongOrNull() ?: 0L
                        },
                        label = { Text("Prix unitaire (FCFA) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("custom_sale_price_input"),
                        singleLine = true
                    )
                }
            }
        }

        // Section Quantité
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Quantité à vendre",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { if (quantity > 1) quantity -= 1 },
                                modifier = Modifier.size(48.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Moins")
                            }

                            Text(
                                text = "$quantity",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )

                            OutlinedButton(
                                onClick = { quantity += 1 },
                                modifier = Modifier.size(48.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Plus")
                            }
                        }

                        // Raccourcis +5, +10
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { quantity += 5 },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("+5")
                            }
                            OutlinedButton(
                                onClick = { quantity += 10 },
                                modifier = Modifier.height(40.dp)
                            ) {
                                Text("+10")
                            }
                        }
                    }

                    if (isStockInsufficient) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = KasuwaRedDanger,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Stock insuffisant ! Disponible seulement : ${selectedProduct?.quantity ?: 0}",
                                style = MaterialTheme.typography.bodySmall,
                                color = KasuwaRedDanger,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Mode de Paiement
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Mode de règlement",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PaymentTypeOption(
                            label = "Espèces",
                            isSelected = paymentType == "CASH",
                            onClick = { paymentType = "CASH" },
                            modifier = Modifier.weight(1f)
                        )
                        PaymentTypeOption(
                            label = "Mobile Money",
                            isSelected = paymentType == "MOBILE_MONEY",
                            onClick = { paymentType = "MOBILE_MONEY" },
                            modifier = Modifier.weight(1f)
                        )
                        PaymentTypeOption(
                            label = "À crédit",
                            isSelected = paymentType == "CREDIT",
                            onClick = { paymentType = "CREDIT" },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Si vente à crédit : Saisie du nom & tél client
                    if (paymentType == "CREDIT") {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Informations client pour le carnet de dettes :",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Nom du client *") },
                            placeholder = { Text("ex: M. Abdoulaye") },
                            modifier = Modifier.fillMaxWidth().testTag("credit_customer_name"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { customerPhone = it },
                            label = { Text("Téléphone (optionnel)") },
                            placeholder = { Text("ex: 96 00 00 00") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth().testTag("credit_customer_phone"),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // Récapitulatif Total & Bouton de Validation
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Total à encaisser :",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = formatFcfa(totalPrice),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val canValidate = (selectedProduct != null || customName.isNotBlank()) &&
                            unitPrice > 0 &&
                            quantity > 0 &&
                            !isStockInsufficient &&
                            (paymentType != "CREDIT" || customerName.isNotBlank())

                    Button(
                        onClick = {
                            onRecordSale(
                                selectedProduct,
                                customName,
                                quantity,
                                unitPrice,
                                unitCostPrice,
                                paymentType,
                                customerName,
                                customerPhone
                            )
                            // Réinitialisation après enregistrement
                            selectedProduct = null
                            customName = ""
                            quantity = 1
                            unitPrice = 0L
                            customerName = ""
                            customerPhone = ""
                        },
                        enabled = canValidate,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("submit_sale_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(
                            text = "Valider la vente (${formatFcfa(totalPrice)})",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Historique des ventes de la journée
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Ventes récentes enregistrées",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (recentSales.isEmpty()) {
            item {
                Text(
                    text = "Aucune vente récente.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(recentSales.take(4)) { sale ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = sale.productName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${sale.quantity}x • ${formatDateShort(sale.timestamp)} • ${sale.paymentType}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = formatFcfa(sale.totalPrice),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentTypeOption(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(44.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
