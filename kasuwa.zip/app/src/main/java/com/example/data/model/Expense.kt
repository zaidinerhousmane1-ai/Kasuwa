package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // Transport, Loyer magasin, Électricité, Emballages, Nourriture, Autre
    val amount: Long,     // Montant en FCFA
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isCancelled: Boolean = false
)
