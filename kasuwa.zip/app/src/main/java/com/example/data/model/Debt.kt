package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val customerPhone: String = "",
    val initialAmount: Long,   // Montant initial de la dette en FCFA
    val amountPaid: Long = 0,  // Montant déjà remboursé en FCFA
    val remainingAmount: Long = initialAmount - amountPaid, // Reste à payer
    val status: String = "PENDING", // PENDING, PARTIAL, PAID
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val isPaid: Boolean
        get() = remainingAmount <= 0
}
