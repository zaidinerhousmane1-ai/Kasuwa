package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.Debt
import com.example.data.model.DebtRepayment
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale
import kotlinx.coroutines.flow.Flow

@Dao
interface KasuwaDao {

    // === PRODUITS & STOCKS ===
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Long): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Update
    suspend fun updateProduct(product: Product)

    @Query("UPDATE products SET quantity = quantity + :delta WHERE id = :productId")
    suspend fun updateStock(productId: Long, delta: Int)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Query("DELETE FROM products")
    suspend fun clearAllProducts()

    // === VENTES ===
    @Query("SELECT * FROM sales ORDER BY timestamp DESC")
    fun getAllSales(): Flow<List<Sale>>

    @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
    suspend fun getSaleById(id: Long): Sale?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: Sale): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSales(sales: List<Sale>)

    @Update
    suspend fun updateSale(sale: Sale)

    @Delete
    suspend fun deleteSale(sale: Sale)

    @Query("DELETE FROM sales")
    suspend fun clearAllSales()

    // === DÉPENSES ===
    @Query("SELECT * FROM expenses ORDER BY timestamp DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Query("SELECT * FROM expenses WHERE id = :id LIMIT 1")
    suspend fun getExpenseById(id: Long): Expense?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(expenses: List<Expense>)

    @Update
    suspend fun updateExpense(expense: Expense)

    @Delete
    suspend fun deleteExpense(expense: Expense)

    @Query("DELETE FROM expenses")
    suspend fun clearAllExpenses()

    // === DETTES CLIENTS ===
    @Query("SELECT * FROM debts ORDER BY updatedAt DESC")
    fun getAllDebts(): Flow<List<Debt>>

    @Query("SELECT * FROM debts WHERE id = :id LIMIT 1")
    suspend fun getDebtById(id: Long): Debt?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: Debt): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebts(debts: List<Debt>)

    @Update
    suspend fun updateDebt(debt: Debt)

    @Delete
    suspend fun deleteDebt(debt: Debt)

    @Query("DELETE FROM debts")
    suspend fun clearAllDebts()

    // === REMBOURSEMENTS DE DETTES ===
    @Query("SELECT * FROM debt_repayments ORDER BY timestamp DESC")
    fun getAllRepayments(): Flow<List<DebtRepayment>>

    @Query("SELECT * FROM debt_repayments WHERE debtId = :debtId ORDER BY timestamp DESC")
    fun getRepaymentsForDebt(debtId: Long): Flow<List<DebtRepayment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepayment(repayment: DebtRepayment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepayments(repayments: List<DebtRepayment>)

    @Query("DELETE FROM debt_repayments")
    suspend fun clearAllRepayments()

    // === TRANSACTIONS MÉTIER ===

    /**
     * Enregistre une vente et décrémente automatiquement le stock du produit si associé.
     * Si la vente est à crédit, crée une entrée de dette client correspondante.
     */
    @Transaction
    suspend fun recordSaleWithInventory(
        sale: Sale,
        isCreditSale: Boolean,
        customerName: String?,
        customerPhone: String?
    ): Long {
        var finalSale = sale
        if (isCreditSale && !customerName.isNullOrBlank()) {
            val debt = Debt(
                customerName = customerName.trim(),
                customerPhone = customerPhone?.trim() ?: "",
                initialAmount = sale.totalPrice,
                amountPaid = 0,
                remainingAmount = sale.totalPrice,
                status = "PENDING",
                notes = "Achat à crédit: ${sale.quantity}x ${sale.productName}"
            )
            val debtId = insertDebt(debt)
            finalSale = finalSale.copy(debtId = debtId, customerName = customerName.trim(), paymentType = "CREDIT")
        }

        val saleId = insertSale(finalSale)

        if (finalSale.productId != null && finalSale.productId > 0) {
            updateStock(finalSale.productId, -finalSale.quantity)
        }
        return saleId
    }

    /**
     * Annule une vente et restitue le stock au magasin.
     */
    @Transaction
    suspend fun cancelSaleAndRestoreStock(saleId: Long) {
        val sale = getSaleById(saleId) ?: return
        if (sale.isCancelled) return

        updateSale(sale.copy(isCancelled = true))
        if (sale.productId != null && sale.productId > 0) {
            updateStock(sale.productId, sale.quantity)
        }
    }

    /**
     * Enregistre un remboursement de dette et met à jour le solde restant.
     */
    @Transaction
    suspend fun recordDebtRepayment(
        debtId: Long,
        amount: Long,
        paymentMethod: String,
        notes: String
    ): Long {
        val debt = getDebtById(debtId) ?: return -1L
        val newAmountPaid = debt.amountPaid + amount
        val newRemaining = (debt.initialAmount - newAmountPaid).coerceAtLeast(0L)
        val newStatus = when {
            newRemaining == 0L -> "PAID"
            newAmountPaid > 0 -> "PARTIAL"
            else -> "PENDING"
        }

        updateDebt(
            debt.copy(
                amountPaid = newAmountPaid,
                remainingAmount = newRemaining,
                status = newStatus,
                updatedAt = System.currentTimeMillis()
            )
        )

        val repayment = DebtRepayment(
            debtId = debtId,
            customerName = debt.customerName,
            amount = amount,
            paymentMethod = paymentMethod,
            notes = notes,
            timestamp = System.currentTimeMillis()
        )
        return insertRepayment(repayment)
    }
}
