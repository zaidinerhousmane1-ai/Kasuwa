package com.example.data.repository

import com.example.data.db.KasuwaDao
import com.example.data.model.Debt
import com.example.data.model.DebtRepayment
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale
import kotlinx.coroutines.flow.Flow

class KasuwaRepository(private val dao: KasuwaDao) {

    val allProducts: Flow<List<Product>> = dao.getAllProducts()
    val allSales: Flow<List<Sale>> = dao.getAllSales()
    val allExpenses: Flow<List<Expense>> = dao.getAllExpenses()
    val allDebts: Flow<List<Debt>> = dao.getAllDebts()
    val allRepayments: Flow<List<DebtRepayment>> = dao.getAllRepayments()

    suspend fun getProductById(id: Long): Product? = dao.getProductById(id)
    suspend fun insertProduct(product: Product): Long = dao.insertProduct(product)
    suspend fun updateProduct(product: Product) = dao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = dao.deleteProduct(product)
    suspend fun updateStock(productId: Long, delta: Int) = dao.updateStock(productId, delta)

    suspend fun recordSale(
        sale: Sale,
        isCreditSale: Boolean,
        customerName: String?,
        customerPhone: String?
    ): Long = dao.recordSaleWithInventory(sale, isCreditSale, customerName, customerPhone)

    suspend fun cancelSale(saleId: Long) = dao.cancelSaleAndRestoreStock(saleId)
    suspend fun deleteSale(sale: Sale) = dao.deleteSale(sale)

    suspend fun insertExpense(expense: Expense): Long = dao.insertExpense(expense)
    suspend fun deleteExpense(expense: Expense) = dao.deleteExpense(expense)

    suspend fun insertDebt(debt: Debt): Long = dao.insertDebt(debt)
    suspend fun updateDebt(debt: Debt) = dao.updateDebt(debt)
    suspend fun deleteDebt(debt: Debt) = dao.deleteDebt(debt)
    suspend fun recordDebtRepayment(
        debtId: Long,
        amount: Long,
        paymentMethod: String,
        notes: String
    ): Long = dao.recordDebtRepayment(debtId, amount, paymentMethod, notes)

    fun getRepaymentsForDebt(debtId: Long): Flow<List<DebtRepayment>> =
        dao.getRepaymentsForDebt(debtId)

    suspend fun clearAllData() {
        dao.clearAllRepayments()
        dao.clearAllDebts()
        dao.clearAllExpenses()
        dao.clearAllSales()
        dao.clearAllProducts()
    }

    /**
     * Charge un jeu de données de démonstration réaliste pour un commerçant de quartier à Niamey.
     */
    suspend fun loadDemoData() {
        clearAllData()

        val now = System.currentTimeMillis()
        val oneHourAgo = now - 3600 * 1000
        val twoHoursAgo = now - 7200 * 1000
        val yesterday = now - 86400 * 1000

        // 1. Produits types d'une boutique / alimentation générale
        val demoProducts = listOf(
            Product(
                id = 1,
                name = "Sac de Riz Parfumé 25kg",
                category = "Alimentation",
                purchasePrice = 16500,
                sellingPrice = 18500,
                quantity = 12,
                lowStockThreshold = 4,
                unit = "sac"
            ),
            Product(
                id = 2,
                name = "Bidon d'Huile Dinor 5L",
                category = "Alimentation",
                purchasePrice = 6200,
                sellingPrice = 7000,
                quantity = 8,
                lowStockThreshold = 3,
                unit = "bidon"
            ),
            Product(
                id = 3,
                name = "Sucre en Morceaux St Louis 1kg",
                category = "Alimentation",
                purchasePrice = 850,
                sellingPrice = 1000,
                quantity = 24,
                lowStockThreshold = 5,
                unit = "paquet"
            ),
            Product(
                id = 4,
                name = "Spaghetti Maman 500g",
                category = "Alimentation",
                purchasePrice = 380,
                sellingPrice = 450,
                quantity = 35,
                lowStockThreshold = 10,
                unit = "paquet"
            ),
            Product(
                id = 5,
                name = "Lait Évaporé Bonnet Rouge",
                category = "Alimentation",
                purchasePrice = 450,
                sellingPrice = 550,
                quantity = 3, // Stock faible !
                lowStockThreshold = 6,
                unit = "boîte"
            ),
            Product(
                id = 6,
                name = "Savon de Marseille BF",
                category = "Hygiène",
                purchasePrice = 275,
                sellingPrice = 350,
                quantity = 2, // Stock faible !
                lowStockThreshold = 5,
                unit = "morceau"
            ),
            Product(
                id = 7,
                name = "Thé Vert Gunpowder 250g",
                category = "Boissons",
                purchasePrice = 1200,
                sellingPrice = 1500,
                quantity = 0, // En rupture !
                lowStockThreshold = 4,
                unit = "paquet"
            ),
            Product(
                id = 8,
                name = "Carton d'Eau Minérale Katako (12x1.5L)",
                category = "Boissons",
                purchasePrice = 3000,
                sellingPrice = 3600,
                quantity = 15,
                lowStockThreshold = 5,
                unit = "carton"
            ),
            Product(
                id = 9,
                name = "Pile R6 Dynamo (paquet de 4)",
                category = "Divers",
                purchasePrice = 600,
                sellingPrice = 800,
                quantity = 14,
                lowStockThreshold = 4,
                unit = "paquet"
            )
        )
        dao.insertProducts(demoProducts)

        // 2. Ventes de démonstration
        val demoSales = listOf(
            Sale(
                id = 1,
                productId = 1,
                productName = "Sac de Riz Parfumé 25kg",
                quantity = 1,
                unitPrice = 18500,
                totalPrice = 18500,
                unitCostPrice = 16500,
                paymentType = "CASH",
                customerName = "Client de passage",
                timestamp = twoHoursAgo
            ),
            Sale(
                id = 2,
                productId = 3,
                productName = "Sucre en Morceaux St Louis 1kg",
                quantity = 2,
                unitPrice = 1000,
                totalPrice = 2000,
                unitCostPrice = 850,
                paymentType = "MOBILE_MONEY",
                customerName = "Mme Fatima (Airtel)",
                timestamp = oneHourAgo
            ),
            Sale(
                id = 3,
                productId = 4,
                productName = "Spaghetti Maman 500g",
                quantity = 4,
                unitPrice = 450,
                totalPrice = 1800,
                unitCostPrice = 380,
                paymentType = "CASH",
                customerName = "Ibrahim",
                timestamp = now - 1800 * 1000
            )
        )
        dao.insertSales(demoSales)

        // 3. Dépenses de démonstration
        val demoExpenses = listOf(
            Expense(
                id = 1,
                category = "Transport",
                amount = 1500,
                description = "Taxi-moto transport de marchandises Grand Marché",
                timestamp = twoHoursAgo
            ),
            Expense(
                id = 2,
                category = "Emballages",
                amount = 1000,
                description = "Lot de sachets plastiques et emballages",
                timestamp = yesterday
            )
        )
        dao.insertExpenses(demoExpenses)

        // 4. Dettes clients de démonstration (Carnet de crédit)
        val debt1 = Debt(
            id = 1,
            customerName = "M. Amadou Seydou",
            customerPhone = "+227 96 12 34 56",
            initialAmount = 14000,
            amountPaid = 5000,
            remainingAmount = 9000,
            status = "PARTIAL",
            notes = "Bidon d'huile 5L + 2 sacs sucre pris le weekend",
            createdAt = yesterday,
            updatedAt = oneHourAgo
        )
        val debt2 = Debt(
            id = 2,
            customerName = "Mme Mariama Garba",
            customerPhone = "+227 90 88 77 66",
            initialAmount = 5500,
            amountPaid = 0,
            remainingAmount = 5500,
            status = "PENDING",
            notes = "Courses de dépannage (boîtes lait et savons)",
            createdAt = now - 7200 * 1000,
            updatedAt = now - 7200 * 1000
        )
        dao.insertDebts(listOf(debt1, debt2))

        val repayment1 = DebtRepayment(
            id = 1,
            debtId = 1,
            customerName = "M. Amadou Seydou",
            amount = 5000,
            paymentMethod = "CASH",
            notes = "Premier versement au magasin",
            timestamp = oneHourAgo
        )
        dao.insertRepayment(repayment1)
    }
}
