package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Debt
import com.example.data.model.DebtRepayment
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale

@Database(
    entities = [
        Product::class,
        Sale::class,
        Expense::class,
        Debt::class,
        DebtRepayment::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KasuwaDatabase : RoomDatabase() {

    abstract fun kasuwaDao(): KasuwaDao

    companion object {
        @Volatile
        private var INSTANCE: KasuwaDatabase? = null

        fun getDatabase(context: Context): KasuwaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KasuwaDatabase::class.java,
                    "kasuwa_commerce_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
