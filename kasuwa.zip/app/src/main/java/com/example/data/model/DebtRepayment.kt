package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "debt_repayments")
data class DebtRepayment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val debtId: Long,
    val customerName: String,
    val amount: Long,          // Montant du versement en FCFA
    val paymentMethod: String = "CASH", // CASH, MOBILE_MONEY
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
