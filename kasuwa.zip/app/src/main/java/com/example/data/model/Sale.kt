package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long? = null,
    val productName: String,
    val quantity: Int,
    val unitPrice: Long,      // Prix de vente unitaire en FCFA
    val totalPrice: Long,     // Montant total en FCFA
    val unitCostPrice: Long,  // Prix d'achat unitaire pour calcul de marge
    val paymentType: String = "CASH", // CASH, MOBILE_MONEY, CREDIT
    val customerName: String? = null,
    val debtId: Long? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isCancelled: Boolean = false
) {
    val estimatedProfit: Long
        get() = (unitPrice - unitCostPrice) * quantity
}
