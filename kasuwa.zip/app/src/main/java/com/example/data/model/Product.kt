package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String = "Alimentation",
    val purchasePrice: Long, // Prix d'achat en FCFA
    val sellingPrice: Long,  // Prix de vente en FCFA
    val quantity: Int,        // Stock disponible
    val lowStockThreshold: Int = 5,
    val unit: String = "pièce", // pièce, sac, carton, kg, bouteille, paquet
    val createdAt: Long = System.currentTimeMillis()
) {
    val margin: Long
        get() = sellingPrice - purchasePrice

    val isLowStock: Boolean
        get() = quantity in 1..lowStockThreshold

    val isOutOfStock: Boolean
        get() = quantity <= 0
}
